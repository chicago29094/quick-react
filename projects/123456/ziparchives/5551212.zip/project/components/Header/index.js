import React from 'react';
    import { Container, Row, Col } from 'react-bootstrap';
import { Navigation } from './components/Navigation';
import './App.css';

/*==========================================================================================*/

    export const Header = (props) => {
    
    
      return (
     
        <div className="App">
    <Navigation />

        </div>
      );
      
    }
    
    export default Header;
    
    