import React from 'react';
import { Container, Row, Col } from 'react-bootstrap';
import './App.css';

/*==========================================================================================*/

    export const Footer = (props) => {
    
    
      return (
     
        <div className="App">
    
        </div>
      );
      
    }
    
    export default Footer;
    
    