import React from 'react';
import { Container, Row, Col } from 'react-bootstrap';
import './App.css';

/*==========================================================================================*/

    export const Footer = (props) => {
    
    
      return (
     
        <div className="footer-container">
    
        </div>
      );
      
    }
    
    export default Footer;
    
    